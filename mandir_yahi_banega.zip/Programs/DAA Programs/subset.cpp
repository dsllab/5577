#include<iostream>
using namespace std;

int s[10], x[10], d;

void sumofsub(int a, int b, int c)
{
	int i=1;
	x[b] = 1;
	if((a+s[b]) == d )
	{
		cout<<"Subset : "<<endl;
		for (i=1; i<=b; i++)
			if( x[i] == 1 )
				cout<<s[i]<<" ";
		cout<<endl;
	}
	else
	{
		if( a + s[b] + s[b+1] <= d)
			sumofsub( a+s[b], b+1, c-s[b] );
		if(( a + c - s[b] >= d ) && ( a + s[b+1] <= d ))
		{
			x[b]=0;
			sumofsub( a, b+1, c-s[b] );
		}
	}
}

int main()
{
	int n, sum=0;
	int i;
	cout<<"Enter the size of set : "<<endl;
	cin>>n;
	cout<<"Enter the set in increasing order : "<<endl;
	for(i=1;i<=n;i++)
		cin>>s[i];
	cout<<"Enter the value of sum : "<<endl;
	cin>>d;
	for(i=1;i<=n;i++)
		sum = sum + s[i];
	if ( sum<d || s[1]>d )
		cout<<"No subset possible"<<endl;
	else
		sumofsub(0,1,sum);
	return 0;
} 
